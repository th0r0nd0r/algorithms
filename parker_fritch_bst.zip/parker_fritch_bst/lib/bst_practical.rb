require_relative "binary_search_tree"

def kth_largest(tree_node, k)
  sorted = in_order_traversal(tree_node, [])
  length = sorted.length
  sorted[length - k]
end

# how do I have access to the BinarySearchTree that has k as the root?

# [0,1,1.5,2,3,4,5,7,9,10]
# largest num == 1st largest
# 7th largest == 2
